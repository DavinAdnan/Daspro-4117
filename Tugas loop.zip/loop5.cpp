#include<iostream>
using namespace std;

int main()
{
    int x;
    cout<<"jika anda menginputkan bilangan -99 maka program akan keluar\n"<<endl;
    while(true){
       cout<<"Masukan Nilai Anda ";
       cin>>x;
       if(x==-99){
          break;
       }
    }
    cout<<"\nKeluar karena Break"<<endl;
    return 0;
}
